-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2021 at 08:23 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ppsi`
--

-- --------------------------------------------------------

--
-- Table structure for table `cuti`
--

CREATE TABLE `cuti` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `nik` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `alasan` varchar(256) NOT NULL,
  `total_hari` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cuti`
--

INSERT INTO `cuti` (`id`, `name`, `nik`, `email`, `alasan`, `total_hari`, `start_date`, `end_date`, `status`) VALUES
(18, 'user', '41817120035', 'user@gmail.com', 'acara keluarga', 1, '2021-06-07', '2021-06-07', 2),
(19, 'user coba', '41817120035', 'user@gmail.com', 'keluar kota', 2, '2021-06-07', '2021-06-08', 3),
(20, 'Ririn Habdiyah', '41817120033', 'rinririnhabdiyyaa@gmail.com', 'acara keluarga', 2, '2021-06-21', '2021-06-22', 3);

-- --------------------------------------------------------

--
-- Table structure for table `lembur`
--

CREATE TABLE `lembur` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `nik` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `alasan` varchar(256) NOT NULL,
  `tanggal` date NOT NULL,
  `start` time NOT NULL,
  `end` time NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lembur`
--

INSERT INTO `lembur` (`id`, `name`, `nik`, `email`, `alasan`, `tanggal`, `start`, `end`, `status`) VALUES
(1, 'Ririn Habdiyah', '41817120033', 'rinririnhabdiyyaa@gmail.com', 'payroll gaji', '2021-06-18', '06:00:00', '09:00:00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `logbook`
--

CREATE TABLE `logbook` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `nik` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `aktivitas` varchar(256) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logbook`
--

INSERT INTO `logbook` (`id`, `name`, `nik`, `email`, `aktivitas`, `tanggal`) VALUES
(0, 'Ririn Habdiyah', '41817120033', 'rinririnhabdiyyaa@gmail.com', 'tes', '2021-04-28'),
(0, 'Ririn Habdiyah', '41817120033', 'rinririnhabdiyyaa@gmail.com', 'tes2', '2021-04-28'),
(0, 'Muhammad Rizky Ramadhan', '41817120079', 'rizkymuhammad66@gmail.com', 'tes', '2021-04-28'),
(0, 'Muhammad Rizky Ramadhan', '41817120079', 'rizkymuhammad66@gmail.com', 'tes4', '2021-04-28'),
(0, 'EKYYY', '41817120034', 'daffa@gmail.com', 'ngerjain laporan', '2021-04-30'),
(0, 'user', '41817120035', 'user@gmail.com', 'membuat PO', '2021-06-04'),
(0, 'user coba', '41817120035', 'user@gmail.com', 'membua DO', '2021-06-04'),
(0, 'Ririn Habdiyah', '41817120033', 'rinririnhabdiyyaa@gmail.com', 'bayar supplier', '2021-06-18');

-- --------------------------------------------------------

--
-- Table structure for table `reimburse`
--

CREATE TABLE `reimburse` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `nik` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `alasan` varchar(256) NOT NULL,
  `tanggal` date NOT NULL,
  `total_pengeluaran` varchar(256) NOT NULL,
  `status` int(11) NOT NULL,
  `image` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reimburse`
--

INSERT INTO `reimburse` (`id`, `name`, `nik`, `email`, `alasan`, `tanggal`, `total_pengeluaran`, `status`, `image`) VALUES
(43, 'Ririn Habdiyah', '41817120033', 'rinririnhabdiyyaa@gmail.com', 'entertain client kopi starbuck', '2021-06-16', '200000', 2, 'struk3.jpeg'),
(44, 'Ririn Habdiyah', '41817120033', 'rinririnhabdiyyaa@gmail.com', 'entertain client', '2021-06-18', '50000', 2, 'struk3.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES
(1, 'admin'),
(2, 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `tb_status`
--

CREATE TABLE `tb_status` (
  `id` int(11) NOT NULL,
  `status_name` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_status`
--

INSERT INTO `tb_status` (`id`, `status_name`) VALUES
(1, 'waiting approval'),
(2, 'approved'),
(3, 'reject');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `role_id` int(11) NOT NULL,
  `lokasi` varchar(128) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `is_active` int(2) NOT NULL,
  `nik` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `image`, `password`, `role_id`, `lokasi`, `unit_id`, `is_active`, `nik`) VALUES
(8, 'Ririn', 'rinririnhabdiyyaa@gmail.com', 'faldiii1.jpg', '$2y$10$Z3dtdmhvO/oTBa0Gx1rf1uIVnnbvQhaKI8Qqag9OTEtm33ldakNKS', 2, 'jakarta', 1, 1, '41817120033'),
(9, 'EKYYY', 'daffa@gmail.com', 'tes.jpeg', '$2y$10$SG7rvshidqKEXOP8udnE8./sA98DR9SKV.Cl8Llb1gNVBUNP.rSAy', 2, 'jakarta', 1, 1, '41817120034'),
(10, 'Muhammad Rizky', 'rizkymuhammad66@gmail.com', 'faldiii.jpg', '$2y$10$CfmxdJGsjsP41vzQC9WSZOnjKK3zpv9xxrI219SoT/U6lhEeVfh/K', 1, 'jakarta', 1, 1, '41817120079'),
(11, 'user coba', 'user@gmail.com', 'eky.jpg', '$2y$10$0xBhKFDU9GdB7r8t7OCvd.6fosP8hNWgfDXDHJxl2WoOoEn7ABoKi', 2, 'jakarta', 1, 1, '41817120035'),
(14, 'karius', 'karius@gmail.com', 'default.jpg', '$2y$10$3ud5JekL3WrFlajZXjk3iOtwzrr5moEJEKTJEUR8ynyTQQVMn.1h.', 2, 'jakarta', 1, 1, '41817120039');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cuti`
--
ALTER TABLE `cuti`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `lembur`
--
ALTER TABLE `lembur`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `reimburse`
--
ALTER TABLE `reimburse`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_status`
--
ALTER TABLE `tb_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cuti`
--
ALTER TABLE `cuti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `lembur`
--
ALTER TABLE `lembur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reimburse`
--
ALTER TABLE `reimburse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_status`
--
ALTER TABLE `tb_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cuti`
--
ALTER TABLE `cuti`
  ADD CONSTRAINT `cuti_ibfk_1` FOREIGN KEY (`status`) REFERENCES `tb_status` (`id`);

--
-- Constraints for table `lembur`
--
ALTER TABLE `lembur`
  ADD CONSTRAINT `lembur_ibfk_1` FOREIGN KEY (`status`) REFERENCES `tb_status` (`id`);

--
-- Constraints for table `reimburse`
--
ALTER TABLE `reimburse`
  ADD CONSTRAINT `reimburse_ibfk_1` FOREIGN KEY (`status`) REFERENCES `tb_status` (`id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

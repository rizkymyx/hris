<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $title; ?></title>

    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url(); ?>assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url(); ?>assets/vendor/datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
    <!-- <link href="<?php echo base_url(); ?>assets/vendor/timepicker/timepicker.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.min.css">


    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo base_url(); ?>assets/css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-dice-d6"></i>
                </div>
                <div class="sidebar-brand-text mx-3">HRIS</div>
            </a>



            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <?php
                $role_id = $this->session->userdata('role_id');

                ?>
                <a class="nav-link" href="<?php

                                            if ($role_id == '1') {
                                                echo base_url('admin');
                                            } else {
                                                echo base_url('user');
                                            }
                                            ?>">
                    <i class="fas fa-user-circle"></i>
                    <span>My Profile</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php

                                            if ($role_id == '1') {
                                                echo base_url('admin/edit');
                                            } else {
                                                echo base_url('user/edit');
                                            }
                                            ?>">
                    <i class=" fas fa-user-circle"></i>
                    <span>Edit My Profile</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Menu
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <?php
                $role_id = $this->session->userdata('role_id');

                ?>
                <a class="nav-link collapsed" href="<?php

                                                    if ($role_id == '1') {
                                                        echo base_url('lembur/lemburAdmin');
                                                    } else {
                                                        echo base_url('lembur');
                                                    }
                                                    ?>">

                    <span>Lembur</span>
                </a>

            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php

                                                    if ($role_id == '1') {
                                                        echo base_url('admin/adminCuti');
                                                    } else {
                                                        echo base_url('user/cuti');
                                                    }
                                                    ?>">
                    <span>Cuti</span>
                </a>
            </li>
            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo base_url('reimburse'); ?>">
                    <span>Rimbursement</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php

                                                    if ($role_id == '1') {
                                                        echo base_url('reimburse/listAdmin');
                                                    } else {
                                                        echo base_url('reimburse/listReimburse');
                                                    }
                                                    ?>">
                    <span>My Rimbursement</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php

                                                    if ($role_id == '1') {
                                                        echo base_url('logbook/logbookAdmin');
                                                    } else {
                                                        echo base_url('logbook');
                                                    }
                                                    ?>">
                    <span>Logbook WFH</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">





            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>



                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">







                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $user['name']; ?></span>
                                <img class="img-profile rounded-circle" src="<?php echo base_url('assets/img/profile/') . $user['image']; ?>">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>

                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?php echo base_url('auth/logout'); ?>" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">


                    <!-- Page Heading -->
                    <?php echo $this->session->flashdata('message'); ?>
                    <form class="col-sm-5 " method="post" action="<?php

                                                                    if ($role_id == '1') {
                                                                        echo base_url('lembur/inputLemburAdmin');
                                                                    } else {
                                                                        echo base_url('lembur/inputLembur');
                                                                    }
                                                                    ?>">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nama</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo $user['name']; ?>" readonly>

                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">NIK</label>
                            <input type="text" class="form-control" id="nik" name="nik" value="<?php echo $user['nik']; ?>" readonly>

                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Email</label>
                            <input type="text" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Alasan</label>
                            <input type="text" class="form-control" id="alasan" name="alasan">
                            <?php echo form_error('alasan', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>


                        <label>Tanggal lembur</label>

                        <div class="input-group date">
                            <div class="input-group-addon">
                                <span class="glyphicon glyphicon-th"></span>
                            </div>
                            <input type="text" class="form-control datepicker" id="tanggal" name="tanggal">
                            <?php echo form_error('tanggal', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                        <br>
                        <div class="bootstrap-timepicker">
                            <div class="form-group">
                                <label>Start Time:</label>

                                <div class="input-group input-group-lg">
                                    <input type="text" class="form-control timepicker" id="start" name="start">

                                    <div class="input-group-addon">
                                        <span class="glyphicon glyphicon-time"></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="bootstrap-timepicker">
                            <div class="form-group">
                                <label>End Time:</label>

                                <div class="input-group input-group-lg">
                                    <input type="text" class="form-control timepicker" id="end" name="end">

                                    <div class="input-group-addon">
                                        <span class="glyphicon glyphicon-time"></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <button type="Submit" class="btn btn-primary">Submit</button>
                        <?php
                        $role_id = $this->session->userdata('role_id');

                        ?>
                        <a class="btn btn-danger" href="<?php

                                                        if ($role_id == '1') {
                                                            echo base_url('lembur/lemburAdmin');
                                                        } else {
                                                            echo base_url('lembur');
                                                        }
                                                        ?>">Cancel</a>
                    </form>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="<?php echo base_url('auth/logout'); ?>">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/vendor/datepicker/js/bootstrap-datepicker.min.js"></script>
    <!-- <script type="text/javascript" src="<?php echo base_url(); ?>assets/vendor/timepicker/timepicker.js"></script> -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/js/bootstrap-timepicker.min.js"></script>



    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url(); ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url(); ?>assets/js/sb-admin-2.min.js"></script>



    <script type="text/javascript">
        $(function() {
            $(".datepicker").datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true,
            });
        });
    </script>

    <script type="text/javascript">
        $(function() {
            $('.timepicker').timepicker({
                showInputs: false
            })
        });
    </script>
    <!-- <script>
        $('.timepicker').timepicker({
            showInputs: false,
            showMeridian: false
        })
    </script> -->

    <!-- <script type="text/javascript">
        $(function() {
            $('#datetimepicker1').datetimepicker();
        });
    </script> -->


</body>


</html>
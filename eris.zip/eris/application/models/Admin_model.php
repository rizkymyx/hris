<?php

class Admin_model extends CI_model
{
    public function getLembur($id)
    {
        return $this->db->get_where('lembur', ['id' => $id])->row_array();
    }
}

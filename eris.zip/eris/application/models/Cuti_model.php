<?php

class Cuti_model extends CI_model
{
    public function total()
    {
        $nik = $this->session->userdata('nik');




        $this->db->select_sum('total_hari');
        $this->db->from('cuti');
        $this->db->where('nik', $nik);
        $this->db->where('status', '2');
        $this->db->where("DATE_FORMAT(start_date,'%Y')", date('Y'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row()->total_hari;
        }
        return false;
    }
}

<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Logbook extends CI_Controller
{
    public function index()
    {
        $data['title'] = 'Logbook WFH';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('logbook/index', $data);
    }
    public function logbookAdmin()
    {
        $data['title'] = 'Logbook';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('logbook/admin', $data);
    }
    public function input()
    {
        $this->form_validation->set_rules('aktivitas', 'Aktivitas', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');

        if ($this->form_validation->run() ==  false) {

            $data['title'] = 'Logbook';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $this->load->view('logbook/input', $data);
        } else {
            $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'nik' => htmlspecialchars($this->input->post('nik', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'aktivitas' => htmlspecialchars($this->input->post('aktivitas', true)),
                'tanggal' => htmlspecialchars($this->input->post('tanggal', true)),


            ];
            $this->db->insert('logbook', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
			Submit Success</div>');
            redirect('logbook');
        }
    }
    public function inputAdmin()
    {
        $this->form_validation->set_rules('aktivitas', 'Aktivitas', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');

        if ($this->form_validation->run() ==  false) {

            $data['title'] = 'Logbook';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $this->load->view('logbook/input', $data);
        } else {
            $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'nik' => htmlspecialchars($this->input->post('nik', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'aktivitas' => htmlspecialchars($this->input->post('aktivitas', true)),
                'tanggal' => htmlspecialchars($this->input->post('tanggal', true)),


            ];
            $this->db->insert('logbook', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
			Submit Success</div>');
            redirect('logbook/logbookAdmin');
        }
    }
}

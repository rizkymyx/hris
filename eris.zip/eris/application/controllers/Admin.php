<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('email')) {
            redirect('auth');
        } else {
            $role_id = $this->session->userdata('role_id');
            if ($role_id == 2) {
                redirect('auth/blocked');
            }
        }
    }
    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();


        $this->load->view('admin/index', $data);
    }

    public function ubah($id)
    {
        $this->form_validation->set_rules('alasan', 'Alasan', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');

        if ($this->form_validation->run() ==  false) {

            $data['title'] = 'Dashboard';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $data['lembur'] = $this->db->get_where('lembur', ['id' => $id])->row_array();
            $this->load->view('admin/ubah', $data);
        } else {


            $data = [
                'id' => ($this->input->post('id', true)),
                'name' => htmlspecialchars($this->input->post('name', true)),
                'nik' => htmlspecialchars($this->input->post('nik', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'alasan' => htmlspecialchars($this->input->post('alasan', true)),
                'tanggal' => htmlspecialchars($this->input->post('tanggal', true)),
                'start' => htmlspecialchars($this->input->post('start', true)),
                'end' => htmlspecialchars($this->input->post('end', true)),
                'status' => ($this->input->post('status', true)),
            ];
            $this->db->where('id', $this->input->post('id'));
            $this->db->update('lembur', $data);
            redirect('lembur/lemburAdmin');
        }
    }

    public function adminCuti()
    {
        $this->load->model('Cuti_model');
        $data['title'] = 'Cuti';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['ambil'] = $this->Cuti_model->total();

        $this->load->view('admin/cuti', $data);
    }
    public function edit()
    {
        $data['title'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');

        if ($this->form_validation->run() == false) {

            $this->load->view('admin/edit', $data);
        } else {

            $name = $this->input->post('name');
            $email = $this->input->post('email');

            //cek jika ada gambar yg akan diupload
            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size']     = '2048';
                $config['upload_path'] = './assets/img/profile/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $old_image = $data['user']['image'];
                    if ($old_image != 'default.jpg') {
                        unlink(FCPATH . 'assets/img/profile/' . $old_image);
                    }

                    $new_image = $this->upload->data('file_name');
                    $this->db->set('image', $new_image);
                } else {
                    echo $this->upload->display_errors();
                }
            }


            $this->db->set('name', $name);
            $this->db->where('email', $email);
            $this->db->update('user');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your profile has been updated</div>');
            redirect('admin');
        }
    }
}

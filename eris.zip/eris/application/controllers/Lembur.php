<?php
defined('BASEPATH') or exit('No direct script access allowed');

class lembur extends CI_Controller
{
    public function index()
    {
        $data['title'] = 'Lembur';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('lembur/index', $data);
    }
    public function lemburAdmin()
    {
        $data['title'] = 'Lembur';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('lembur/lemburAdmin', $data);
    }

    public function inputLembur()
    {
        $this->form_validation->set_rules('alasan', 'Alasan', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');

        if ($this->form_validation->run() ==  false) {

            $data['title'] = 'Lembur';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $this->load->view('lembur/input', $data);
        } else {
            $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'nik' => htmlspecialchars($this->input->post('nik', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'alasan' => htmlspecialchars($this->input->post('alasan', true)),
                'tanggal' => htmlspecialchars($this->input->post('tanggal', true)),
                'start' => htmlspecialchars($this->input->post('start', true)),
                'end' => htmlspecialchars($this->input->post('end', true)),
                'status' => '1',
            ];
            $this->db->insert('lembur', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
			Submit Success</div>');
            redirect('lembur');
        }
    }
    public function inputLemburAdmin()
    {
        $this->form_validation->set_rules('alasan', 'Alasan', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');

        if ($this->form_validation->run() ==  false) {

            $data['title'] = 'Lembur';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $this->load->view('lembur/input', $data);
        } else {
            $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'nik' => htmlspecialchars($this->input->post('nik', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'alasan' => htmlspecialchars($this->input->post('alasan', true)),
                'tanggal' => htmlspecialchars($this->input->post('tanggal', true)),
                'start' => htmlspecialchars($this->input->post('start', true)),
                'end' => htmlspecialchars($this->input->post('end', true)),
                'status' => '1',
            ];
            $this->db->insert('lembur', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
			Submit Success</div>');
            redirect('lembur/lemburAdmin');
        }
    }
}

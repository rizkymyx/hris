<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cuti extends CI_Controller
{

    public function index()
    {
        $this->load->model('Cuti_model');
        $this->form_validation->set_rules('alasan', 'Alasan', 'required');
        $this->form_validation->set_rules('hari', 'Hari', 'required');



        if ($this->form_validation->run() ==  false) {
            $data['title'] = 'Cuti';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $data['ambil'] = $this->Cuti_model->total();
            $this->load->view('cuti/input', $data);
        } else {
            $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'nik' => htmlspecialchars($this->input->post('nik', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'alasan' => htmlspecialchars($this->input->post('alasan', true)),
                'total_hari' => htmlspecialchars($this->input->post('hari', true)),
                'start_date' => ($this->input->post('tanggal_awal', true)),
                'end_date' => ($this->input->post('tanggal_akhir', true)),
                'status' => '1',
            ];
            $this->db->insert('cuti', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
			Submit Success</div>');
            redirect('user/cuti');
        }
    }
    public function inputAdminCuti()
    {

        $this->load->model('Cuti_model');
        $this->form_validation->set_rules('alasan', 'Alasan', 'required');
        $this->form_validation->set_rules('hari', 'Hari', 'required');



        if ($this->form_validation->run() ==  false) {
            $data['title'] = 'Cuti';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $data['ambil'] = $this->Cuti_model->total();
            $this->load->view('cuti/input', $data);
        } else {
            $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'nik' => htmlspecialchars($this->input->post('nik', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'alasan' => htmlspecialchars($this->input->post('alasan', true)),
                'total_hari' => htmlspecialchars($this->input->post('hari', true)),
                'start_date' => ($this->input->post('tanggal_awal', true)),
                'end_date' => ($this->input->post('tanggal_akhir', true)),
                'status' => '1',
            ];
            $this->db->insert('cuti', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
			Submit Success</div>');
            redirect('admin/adminCuti');
        }
    }

    public function ubahCuti($id)
    {
        $this->form_validation->set_rules('alasan', 'Alasan', 'required');
        $this->form_validation->set_rules('start_date', 'Tanggal', 'required');

        if ($this->form_validation->run() ==  false) {

            $data['title'] = 'Ubah';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $data['lembur'] = $this->db->get_where('cuti', ['id' => $id])->row_array();
            $this->load->view('admin/ubahCuti', $data);
        } else {


            $data = [
                'id' => ($this->input->post('id', true)),
                'name' => htmlspecialchars($this->input->post('name', true)),
                'nik' => htmlspecialchars($this->input->post('nik', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'alasan' => htmlspecialchars($this->input->post('alasan', true)),
                'total_hari' => htmlspecialchars($this->input->post('total_hari', true)),
                'start_date' => htmlspecialchars($this->input->post('start_date', true)),
                'end_date' => htmlspecialchars($this->input->post('end_date', true)),
                'status' => ($this->input->post('status', true)),
            ];
            $this->db->where('id', $this->input->post('id'));
            $this->db->update('cuti', $data);
            redirect('admin/adminCuti');
        }
    }
}

<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Reimburse extends CI_Controller
{
    public function index()
    {
        $data['title'] = 'Reimburse';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('reimburse/index', $data);
    }

    public function inputReimburse()
    {
        $this->form_validation->set_rules('alasan', 'Alasan', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');

        if ($this->form_validation->run() ==  false) {

            $data['title'] = 'reimburse';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $this->load->view('reimburse/index', $data);
        } else {

            $file_name = $_FILES['image']['name'];
            if ($file_name) {
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size']     = '2048';
                $config['upload_path'] = './assets/img/reimburse/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $data['image'] = $file_name;
                    $data['name'] = $this->input->post('name');
                    $data['nik'] = $this->input->post('nik');
                    $data['email'] = $this->input->post('email');
                    $data['alasan'] = $this->input->post('alasan');
                    $data['tanggal'] = $this->input->post('tanggal');
                    $data['total_pengeluaran'] = $this->input->post('total_pengeluaran');
                    $data['status'] = '1';
                } else {
                    echo $this->upload->display_errors();
                }
            }
            $this->db->insert('reimburse', $data);
            redirect('reimburse');
        }
    }
    public function listReimburse()
    {
        $data['title'] = 'Reimburse';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('reimburse/list', $data);
    }
    public function listAdmin()
    {
        if (!$this->session->userdata('email')) {
            redirect('auth');
        } else {
            $role_id = $this->session->userdata('role_id');
            if ($role_id == 2) {
                redirect('auth/blocked');
            }
        }
        $data['title'] = 'Reimburse';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('admin/list', $data);
    }
    public function ubahReimburse($id)
    {
        $this->form_validation->set_rules('alasan', 'Alasan', 'required');


        if ($this->form_validation->run() ==  false) {

            $data['title'] = 'Ubah';
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $data['lembur'] = $this->db->get_where('reimburse', ['id' => $id])->row_array();
            $this->load->view('admin/ubahReimburse', $data);
        } else {


            $data = [
                'id' => ($this->input->post('id', true)),
                'name' => htmlspecialchars($this->input->post('name', true)),
                'nik' => htmlspecialchars($this->input->post('nik', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'alasan' => htmlspecialchars($this->input->post('alasan', true)),
                'tanggal' => htmlspecialchars($this->input->post('tanggal', true)),
                'total_pengeluaran' => htmlspecialchars($this->input->post('total_pengeluaran', true)),

                'status' => ($this->input->post('status', true)),
            ];
            $this->db->where('id', $this->input->post('id'));
            $this->db->update('reimburse', $data);
            redirect('reimburse/listAdmin');
        }
    }
}
